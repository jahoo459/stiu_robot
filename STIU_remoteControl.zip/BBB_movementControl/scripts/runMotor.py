#!/usr/bin/python

import MotorControllerLib as motor
import time
import rospy
from movementControl.msg import *

class myMotor:
    def __init__(self, ID, pwmChannel, IN1, IN2, PWM_period):
        self.mMotor = motor.Motor(pwmChannel, IN1, IN2, PWM_period)
        self.mID = ID 
        
        
def callback(data):
    if(data.id == wheelMotor.mID):
        wheelMotor.mMotor.setDirection(data.direction)
        wheelMotor.mMotor.setSpeed(data.speed)
        wheelMotor.mMotor.start()
        print("Updated motor speed. New speed is:", data.speed, "\n")
    
def listener():
    rospy.Subscriber("click", MotorCmd, callback)
    rospy.spin()


if __name__ == '__main__':
    
    if len(sys.argv) < 4:
        print("usage: runMotor [ID] [PWM_PORT] [A_IN_port] [B_IN_PORT]")
    
    else:
        rospy.init_node('runMotor', anonymous=True)
        wheelMotor = myMotor(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], 1000000)
        wheelMotor.mMotor.setSpeed(0)
        wheelMotor.mMotor.stop()
        try:
            listener()
        except rospy.ROSInterruptException:
            pass